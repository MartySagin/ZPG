#include "DrawableObject.h"
#include <glm/gtc/matrix_transform.hpp>

DrawableObject::DrawableObject(ShaderProgram* shaderProgram, Model* model, glm::vec3 objectColor, Material* material)
	: shaderProgram(*shaderProgram), model(*model), material(*material)
{
	this->transform = Transformation();

	this->objectColor = objectColor;

	this->texture = nullptr;
}

DrawableObject::DrawableObject(ShaderProgram* shaderProgram, Model* model, Material* material, Texture* texture)
	: shaderProgram(*shaderProgram), model(*model), material(*material), texture(texture)
{
	this->transform = Transformation();

	this->objectColor = glm::vec3(1.0f);

}

DrawableObject::DrawableObject(ShaderProgram* shaderProgram, ModelObject* model, Material* material, Texture* texture)
	: shaderProgram(*shaderProgram), model(*model), material(*material), texture(texture)
{
	this->transform = Transformation();

	this->objectColor = glm::vec3(1.0f);
}

void DrawableObject::SetObjectID(int objectID)
{
	this->objectID = objectID;
}

int DrawableObject::GetObjectID() {
	return this->objectID;
}

Transformation* DrawableObject::GetTransformation()
{
	return &this->transform;
}

ShaderProgram* DrawableObject::GetShaderProgram()
{
	return &this->shaderProgram;
}

void DrawableObject::Draw()
{
	
	this->shaderProgram.UseProgram();

	if (this->texture != nullptr) {
		this->texture->ActivateTexture();

		this->shaderProgram.SetIntUniform("hasTexture", 1);

		this->shaderProgram.SetIntUniform("textureUnit", this->texture->GetTextureUnit());
	}
	else {
		this->shaderProgram.SetIntUniform("hasTexture", 0); 

		this->shaderProgram.SetVec3Uniform("objectColor", this->objectColor);
	}

	this->shaderProgram.SetMat4Uniform("modelMatrix", this->transform.GetModelMatrix());

	this->shaderProgram.SetFloatUniform("material.ra", this->material.GetAmbientCoefficient());

	this->shaderProgram.SetFloatUniform("material.rd", this->material.GetDiffuseCoefficient());

	this->shaderProgram.SetFloatUniform("material.rs", this->material.GetSpecularCoefficient());

	this->shaderProgram.SetIntUniform("material.shininess", this->material.GetShininess());

	this->model.BindVAO();

	this->shaderProgram.Draw();

	this->model.UnbindVAO();

	this->shaderProgram.DisableProgram();

	
}


